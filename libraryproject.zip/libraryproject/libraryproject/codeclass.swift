//
//  codeclass.swift
//  libraryproject
//
//  Created by Lavpreet Kaur on 2017-10-14.
//  Copyright © 2017 Kirankomal. All rights reserved.
//

import Foundation
class CodeClass : Library
{
    func showCategoryCount(ob:CodeClass){
        var bcat=ob.getbookcategory()
        var cat=ob.getcategory()
        var counts: [String: Int] = [:]
        for item in bcat {
            counts[item] = (counts[item] ?? 0) + 1
        }
        print("\n\nSNO \t\tCategory Name\t\t\tBook Count")
        var sn=1
        
        for (key, value) in counts {
            var j:Int=Int(key)!
            print("\(sn)\t\t\t\(cat[j])\t\t\t\t\(value)")
            sn+=1
        }
    }
    func showRackBookCount(ob:CodeClass){
        var rack=ob.getrackno()
        var brack=ob.getbookrack()
        var counts: [String: Int] = [:]
        for item in brack {
            counts[item] = (counts[item] ?? 0) + 1
        }
        print("\n\nSNO \t\tRack Name\t\t\tBook Count")
        var sn=1
        
        for (key, value) in counts {
            var j:Int=Int(key)!
            print("\(sn)\t\t\t\(rack[j])\t\t\t\t\(value)")
            sn+=1
        }
    }
    func MaxBorrow(ob:CodeClass){
        var booktake=ob.getbookuser()
        var user=ob.getusername()
        var userbook=ob.getuserbook()
        var book=ob.getbooksname()
        print ("SNO\t\tUsername\t\t\tBook Name\n")
        
        for i in 0..<booktake.count{
            var j=Int(userbook[i])!
            var h=Int(booktake[i])!
            print("\(i+1)\t\t\(user[j])\t\t\t\(book[h])")
        }
        print ("User With Maximum Borrow is ")
        var counts: [String: Int] = [:]
        var userindex:[Int]=[]
        var usercount:[Int]=[]
        for item in userbook {
            counts[item] = (counts[item] ?? 0) + 1
        }
        
        for (key, value) in counts {
            var k=Int(key)!
            userindex.append(k)
            usercount.append(value)
        }

        for row in 0..<usercount.count {
            var l=row+1
            for j in l..<usercount.count
            {
                if (usercount[row] < usercount[j]) {
                    var temp = usercount[row];
                    usercount[row] = usercount[j];
                    usercount[j] = temp;
                    
                    var t = userindex[row];
                    userindex[row] = userindex[j];
                    userindex[j] = t;
                }
            }
        }

        var la=userindex[0]
        print("\(user[la]) had boorrowed \(usercount[0]) times book from Library")
    }
    
    func getFineListUse(ob:CodeClass){
        var fine=ob.getfine()
        var user=ob.getusername()
        var status=ob.getfinestatus()
        var userfine=ob.getfuserfine()
        print("SNO\t\tUser Name\t\tFine\t\tFine Status")
        for i in 0..<fine.count{
            var id=Int(userfine[i])!
            print("\(i+1)\t\t\(user[id])\t\t\t\(fine[i])\t\t\t\t\(status[i])")
        }
    }
    func getBookYearCount(ob:CodeClass){
        var book=ob.getbooksname()
        var year=ob.getyear()
        print("SNO\t\tBook Name\t\tYear")
        for i in 0..<book.count{
            print("\(i+1)\t\t\(book[i])\t\t\(year[i])")
        }
       
        var counts: [String: Int] = [:]
        for item in year {
            counts[item] = (counts[item] ?? 0) + 1
        }
        print("\n\nYear\t\t\tBook Count")
        for (key, value) in counts {
            print("\(key)\t\t\t\t\(value)")
        }
        
    }
}



