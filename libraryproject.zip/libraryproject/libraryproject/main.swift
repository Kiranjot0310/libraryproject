//
//  main.swift
//  libraryproject
//
//  Created by Lavpreet Kaur on 2017-10-14.
//  Copyright © 2017 Kirankomal. All rights reserved.
//

import Foundation
var books=["Tinker Bell","Tom and Jeery","Oracle","Alogrithm","The secret The power","JAVA Fundamentals","The Hobbit"]
var year=["2009","2010","2009","2011","2009","2010","2010"]
var bookrack=["0","0","1","1","1","0","0"]
var bookCategory=["0","1","2","3","4","2","0"]

var category=["Story","Fiction","Computer Science","IT","Autobiography"]

var noOfBooks=["3","1","3","5","3"]
var rack=["Rack 1","Rack 2"]
var user=["Kiran","Kamal","Vishal","Rohit","Aman"]
var type=["Teacher","Student","Student","Teacher","Student"]

var booktake=["1","3","0","4","0","1","2","5","5","5","6","3"]
var bookuser=["0","4","1","2","0","3","4","4","4","4","4","3"]

var userfine=["0","3","2","0","2","3"]
var fine=["10","20","90","30","15","34"]
var status=["Paid","Not Paid","Paid","Not Paid","Paid","Paid"]
var obj=CodeClass()

obj.setyear(yr: year)
obj.setcategory(cat: category)

obj.setbooksname(bk: books)

obj.setbookcategory(bkcategory: bookCategory)
obj.setbookrack(bookrk: bookrack)
obj.setrackno(rkno: rack)
obj.setuserbook(userbook: bookuser)
obj.setbookuser(bookur: booktake)
obj.setusername(user: user)

obj.setuserfine(urfine: userfine)
obj.setfine(fine: fine)
obj.setfinestatus(fineS: status)


//obj.showCategoryCount(ob:obj)
//obj.showRackBookCount(ob:obj)
//obj.MaxBorrow(ob:obj)
//obj.getFineListUse(ob:obj)
obj.getBookYearCount(ob:obj)
