//
//  project.swift
//  libraryproject
//
//  Created by Lavpreet Kaur on 2017-10-14.
//  Copyright © 2017 Kirankomal. All rights reserved.
//

import Foundation
class Library
{
    public private(set) var booksname:[String]=[]
    public private(set) var year:[String]=[]
    public private(set) var category:[String]=[]
    public private(set) var noOfbooks:[String]=[]
    public private(set) var bookcategory:[String]=[]
    public private(set) var fine:[String]=[]
    public private(set) var finestatus:[String]=[]
    
    public private(set) var userfine:[String]=[]
    
    public private(set) var rackno:[String]=[]
    public private(set) var bookrack:[String]=[]
    public private(set) var bookuser:[String]=[]
    public private(set) var userbook:[String]=[]
    public private(set) var username:[String]=[]
    
    func setbooksname(bk:Array<String>)
    {
        self.booksname=bk
    }
    func getbooksname()->Array<String>
    {
        return self.booksname
    }
    func setyear(yr:Array<String>)
    {
        self.year=yr
    }
    func getyear()->Array<String>
    {
        return self.year
    }
    func setcategory(cat:Array<String>)
    {
        self.category=cat
    }
    func getcategory()->Array<String>
    {
        return self.category
    }
    func setnoOfBooks(nob:Array<String>)
    {
        self.noOfbooks=nob
    }
    func getnoOfBooks()->Array<String>
    {
        return self.noOfbooks
    }
    
    func setbookcategory(bkcategory:Array<String>)
    {
        self.bookcategory=bkcategory
    }
    func getbookcategory()->Array<String>
    {
        return self.bookcategory
    }
    func setfine(fine:Array<String>)
    {
        self.fine=fine
    }
    func getfine()->Array<String>
    {
        return self.fine
    }
    func setfinestatus(fineS:Array<String>)
    {
        self.finestatus=fineS
    }
    func getfinestatus()->Array<String>
    {
        return self.finestatus
    }
    func setuserfine(urfine:Array<String>)
    {
        self.userfine=urfine
    }
    func getfuserfine()->Array<String>
    {
        return self.userfine
    }
    func setrackno(rkno:Array<String>)
    {
        self.rackno=rkno
    }
    func getrackno()->Array<String>
    {
        return self.rackno
    }
    func setbookrack(bookrk:Array<String>)
    {
        self.bookrack=bookrk
    }
    func getbookrack()->Array<String>
    {
        return self.bookrack
    }
    func setbookuser(bookur:Array<String>)
    {
        self.bookuser=bookur
        
    }
    func getbookuser()->Array<String>
    {
        return self.bookuser
    }
    func setuserbook(userbook:Array<String>){
        self.userbook=userbook
        
    }
    func getuserbook()->Array<String>
    {
        return self.userbook
    }
    func setusername(user:Array<String>){
        self.username=user
        
    }
    func getusername()->Array<String>
    {
        return self.username
    }
    
   
    }
